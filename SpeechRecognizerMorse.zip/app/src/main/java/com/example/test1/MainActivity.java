package com.example.test1;

        import androidx.appcompat.app.AppCompatActivity;
        import androidx.core.app.ActivityCompat;
        import androidx.core.content.ContextCompat;

        import android.Manifest;
        import android.annotation.SuppressLint;
        import android.content.Intent;
        import android.content.pm.PackageManager;
        import android.os.Bundle;
        import android.speech.RecognizerIntent;
        import android.speech.SpeechRecognizer;
        import android.util.Log;
        import android.view.MotionEvent;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.ImageButton;
        import android.widget.TextView;
        import android.widget.Toast;

        import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ImageButton micro;
    Button otherpage;
    EditText UserTextET;
    Button button;
    TextView itog;
    String UserTextMorse;
    SpeechRecognizer speechRecognizer;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupUI();
        checkPermission();
        if (SpeechRecognizer.isRecognitionAvailable(this)) { // важно, чтобы на телефоне стояло приложение Google
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            Log.d("RRR", SpeechRecognizer.isRecognitionAvailable(this) + "");
            Intent speechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speechRecognizer.setRecognitionListener(new RecognitionListener());
            micro.setOnTouchListener((view, event) -> {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: // положил палец на кнопку
                        micro.setImageDrawable(getDrawable(R.drawable.micro));
                        speechRecognizer.startListening(speechRecognizerIntent);
                        return true;

                    case MotionEvent.ACTION_UP: // убрал палец с кнопки
                        micro.setImageDrawable(getDrawable(R.drawable.not_micro));
                        speechRecognizer.stopListening();
                        return true;
                }
                return false;
            });
        }
    }

    private void checkPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, 1);
    }

    public void back(View view) {
        Intent intent1 = new Intent(this, SecondActivity.class);
        startActivity(intent1);
    }

    public void click(View view) {
        String UserText = UserTextET.getText().toString();
        UserTextMorse = UserText
                .replace("a", " ·− ").replace("A", " ·− ")
                .replace("а", " ·− ").replace("А", " ·− ")
                .replace("b", " −··· ").replace("B", " −··· ")
                .replace("б", " −··· ").replace("Б", " −··· ")
                .replace("w", " ·−− ").replace("W", " ·−− ")
                .replace("в", " ·−− ").replace("В", " ·−− ")
                .replace("g", " −−· ").replace("G", " −−· ")
                .replace("г", " −−· ").replace("Г", " −−· ")
                .replace("d", " −·· ").replace("D", " −·· ")
                .replace("д", " −·· ").replace("Д", " −·· ")
                .replace("e", " · ").replace("E", " · ")
                .replace("е", " · ").replace("Е", " · ")
                .replace("ё", " · ").replace("Ё", " · ")
                .replace("v", " ···− ").replace("V", " ···− ")
                .replace("ж", " ···− ").replace("Ж", " ···− ")
                .replace("z", " −−·· ").replace("Z", " −−·· ")
                .replace("з", " −−·· ").replace("З", " −−·· ")
                .replace("i", " ·· ").replace("I", " ·· ")
                .replace("и", " ·· ").replace("И", " ·· ")
                .replace("j", " ·−−− ").replace("J", " ·−−− ")
                .replace("й", " ·−−− ").replace("Й", " ·−−− ")
                .replace("k", " −·− ").replace("K", " −·− ")
                .replace("к", " −·− ").replace("К", " −·− ")
                .replace("l", " ·−·· ").replace("L", " ·−·· ")
                .replace("л", " ·−·· ").replace("Л", " ·−·· ")
                .replace("m", " −− ").replace("M", " −− ")
                .replace("м", " −− ").replace("М", " −− ")
                .replace("n", " −· ").replace("N", " −· ")
                .replace("н", " −· ").replace("Н", " −· ")
                .replace("o", " −−− ").replace("O", " −−− ")
                .replace("о", " −−− ").replace("О", " −−− ")
                .replace("p", " ·−−· ").replace("P", " ·−−· ")
                .replace("п", " ·−−· ").replace("П", " ·−−· ")
                .replace("r", " ·−· ").replace("R", " ·−· ")
                .replace("р", " ·−· ").replace("Р", " ·−· ")
                .replace("s", " ··· ").replace("S", " ··· ")
                .replace("с", " ··· ").replace("С", " ··· ")
                .replace("t", " − ").replace("T", " − ")
                .replace("т", " − ").replace("Т", " − ")
                .replace("u", " ··− ").replace("U", " ··− ")
                .replace("у", " ··− ").replace("У", " ··− ")
                .replace("f", " ··−· ").replace("F", " ··−· ")
                .replace("ф", " ··−· ").replace("Ф", " ··−· ")
                .replace("h", " ···· ").replace("H", " ···· ")
                .replace("х", " ···· ").replace("Х", " ···· ")
                .replace("c", " −·−· ").replace("C", " −·−· ")
                .replace("ц", " −·−· ").replace("Ц", " −·−· ")
                .replace("ч", " −−−· ").replace("Ч", " −−−· ")
                .replace("ш", " −−−− ").replace("Ш", " −−−− ")
                .replace("q", " −−·− ").replace("Q", " −−·− ")
                .replace("щ", " −−·− ").replace("Щ", " −−·− ")
                .replace("ъ", " −−·−− ").replace("Ъ", " −−·−− ")
                .replace("ы", " −·−− ").replace("Ы", " −·−− ")
                .replace("y", " −·−− ").replace("Y", " −·−− ")
                .replace("ь", " −··− ").replace("Ь", " −··− ")
                .replace("x", " −··− ").replace("X", " −··− ")
                .replace("э", " ··−·· ").replace("Э", " ··−·· ")
                .replace("ю", " ··−− ").replace("Ю", " ··−− ")
                .replace("я", " ·−·− ").replace("Я", " ·−·− ")
                .replace("1", " ·−−−− ").replace("2", " ··−−− ")
                .replace("3", " ···−− ").replace("4", " ····− ")
                .replace("5", " ····· ").replace("6", " −···· ")
                .replace("7", " −−··· ").replace("8", " −−−·· ")
                .replace("9", " −−−−· ").replace("0", " −−−−− ")
                .replace(".", " ······ ").replace(",", " ·−·−·− ")
                .replace(":", " −−−··· ").replace(";", " −·−·−· ")
                .replace("(", " −·−−· ").replace(")", " −·−−·− ")
                .replace("'", " ·−−−−· ").replace("\"", " ·−··−· ")
                .replace("-", " −····− ").replace("/", " −··−· ")
                .replace("_", " ··−−·− ").replace("?", " ··−−·· ")
                .replace("!", " −−··−− ").replace("+", " ·−·−· ")
                .replace("§", " −···− ").replace("¶", " ·−·−· ")
                .replace("@", " ·−−·−· ");
        itog.setText(UserTextMorse);
        Toast.makeText(this, UserTextMorse, Toast.LENGTH_SHORT).show();
    }

    private void setupUI(){
        UserTextET =  findViewById(R.id.your_text);
        button = findViewById(R.id.button);
        button = findViewById(R.id.otherpage);
        itog = findViewById(R.id.itog);
        micro = findViewById(R.id.micro);
    }
    class RecognitionListener implements android.speech.RecognitionListener {

        @Override
        public void onReadyForSpeech(Bundle bundle) {

        }

        @Override
        public void onBeginningOfSpeech() {

        }

        @Override
        public void onRmsChanged(float v) {

        }

        @Override
        public void onBufferReceived(byte[] bytes) {

        }

        @Override
        public void onEndOfSpeech() {

        }

        @Override
        public void onError(int i) {
            Log.d("RRR", i  + "");
        }


        @Override
        public void onResults(Bundle bundle) {
            Log.d("RRR", "onResults");
            ArrayList<String> data = bundle.getStringArrayList(speechRecognizer.RESULTS_RECOGNITION);
            UserTextET.setText(data.get(0));
        }

        @Override
        public void onPartialResults(Bundle bundle) {

        }

        @Override
        public void onEvent(int i, Bundle bundle) {

        }
    }
}