package com.example.test1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    EditText UserTextET;
    Button button;
    TextView itog;
    String UserTextMorse;
    EditText SymblSmall;
    EditText SymblLarge;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);
        setupUI();
    }

    //public void back2(View view) {
    //    Intent intent2 = new Intent(this, MainActivity.class);
    //    startActivity(intent2);
    //}
    public void back2(View view){
        Intent intent2 = new Intent(this, MainActivity.class);
        startActivity(intent2);
    }

    public void click(View view) {
        String SymblSmallCode = SymblSmall.getText().toString();
        String SymblLargeCode = SymblLarge.getText().toString();
        String UserText = UserTextET.getText().toString();
        //StringBuffer sb = new StringBuffer("a");
        //sb.insert(1,"d");
        UserTextMorse = UserText.substring(0, 0) + " " + UserText.substring(0, UserText.length()) + " ";
        UserTextMorse = UserTextMorse
                .replace(SymblLargeCode,"−")
                .replace(SymblSmallCode,"·");
        UserTextMorse = UserTextMorse
                .replace(" ","  ")
                .replace(" ·− ", " а ")
                .replace(" −··· ", " б ")
                .replace(" ·−− ", " в ")
                .replace(" −−· ", " г ")
                .replace(" −·· ", "д")
                .replace(" · ", "е")
                .replace(" · ", "ё")
                .replace(" ···− ", "ж")
                .replace(" −−·· ", "з")
                .replace(" ·· ", "и")
                .replace(" ·−−− ", "й")
                .replace(" −·− ", "к")
                .replace(" ·−·· ", "л")
                .replace(" −− ", "м")
                .replace(" −· ", "н")
                .replace(" −−− ", "о")
                .replace(" ·−−· ", "п")
                .replace(" ·−·", "р")
                .replace(" ··· ", "с")
                .replace(" − ", "т")
                .replace(" ··− ", "у")
                .replace(" ··−· ", "ф")
                .replace(" ···· ", "х")
                .replace(" −·−· ", "ц")
                .replace(" −−−· ", "ч")
                .replace(" −−−− ", "ш")
                .replace(" −−·− ", "щ")
                .replace(" −−·−− ", "ъ")
                .replace(" −·−− ", "ы")
                .replace(" −··− ", "ь")
                .replace(" ··−·· ", "э")
                .replace(" ··−− ", "ю")
                .replace(" ·−·− ", "я")
                .replace(" ·−−−−", "1").replace(" ··−−− ", "2")
                .replace(" ···−− ", "3").replace(" ····− ", "4")
                .replace(" ····· ", "5").replace(" −···· ", "6")
                .replace(" −−··· ", "7").replace(" −−−·· ", "8")
                .replace(" −−−−· ", "9").replace(" −−−−− ", "0")
                .replace(" ······ ", ".").replace(" ·−·−·− ", ",")
                .replace(" −−−··· ", ":").replace(" −·−·−· ", ";")
                .replace(" −·−−· ", "(").replace(" −·−−·− ", ")")
                .replace(" ·−−−−· ", "'").replace(" ·−··−· ", "\"")
                .replace(" −····− ", "-").replace(" −··−· ", "/")
                .replace(" ··−−·− ", "_").replace(" ··−−·· ", "?")
                .replace(" −−··−− ", "!").replace(" ·−·−· ", "+")
                .replace(" −···− ", "§").replace(" ·−·−· ", "¶")
                .replace(" ·−−·−· ", "@").replace(" ········", " [ОШИБКА] ");
        UserTextMorse = UserTextMorse.replace("·", "").replace("−", "");
        itog.setText(UserTextMorse);
        Toast.makeText(this, UserTextMorse, Toast.LENGTH_SHORT).show();
    }

    private void setupUI(){
        UserTextET =  findViewById(R.id.your_text2);
        button = findViewById(R.id.button);
        itog = findViewById(R.id.itog);
        SymblSmall = findViewById(R.id.smallsymbl);
        SymblLarge = findViewById(R.id.largesymbl);
    }

}